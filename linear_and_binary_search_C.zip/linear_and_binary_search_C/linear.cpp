#include <iostream>
//Ogrenci ad: Ali Arslan
//Ogrenci no: 1210505017


using namespace std;

int dogrusalara(int dizi[],int byt,int ara){
	
	for(int j=0;j<byt;j++){
		if(dizi[j]==ara)
		return j;
	}
	return -1;
	}
	
int main() {
	int ara;
	int dizi[100],byt,i;
	
	cout<<"Dizinin boyutunu giriniz: ";
	cin>>byt;
	
	cout<<"Dizinin elemanlarini giriniz: "<<endl;
	
	for(i=0;i<byt;i++){
		
		cin>>dizi[i];
	}
	
	cout<<"Bulmak istediginiz degeri giriniz: ";
	cin>>ara;
	
	
	
	int cvp=dogrusalara(dizi,byt,ara);
	if (cvp==-1){
		cout<<"Aranan deger dizide yoktur";
		
	}
	else{
		cout<<"Aranan deger dizide vardir indisi :"<<cvp;
	}
	
	return 0;
}
