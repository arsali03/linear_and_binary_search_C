#include <iostream>
//Ogrenci ad: Ali Arslan
//Ogrenci no: 1210505017

using namespace std;
 
int binarama(int dizi[], int bas, int son, int ara){
	
    int ort;
    
    if (son>=bas){
    	
        ort=(bas + son)/2;
        
        if (dizi[ort] == ara) 
               return ort;
        
        if (dizi[ort] > ara)
               return binarama(dizi, bas, ort-1, ara);
        
          else
               return binarama(dizi, ort+1, son, ara);
    }    
    
    else
        return -1 ;
}


int main(){
	
	int bul;
	
	cout<<"Aranan degeri giriniz: ";
	cin>>bul;
	
	int dizi[9] = {1,7,3,88,34,76,9,24,45};
    
    for(int adm=1; adm<9; adm++){
    	
        for(int j=0; j<9-adm; j++){
        	
            if(dizi[j] > dizi[j+1]){
            	
                int arc = dizi[j];
                dizi[j] = dizi[j+1];
                dizi[j+1] = arc;
        	}
    	}
	}
    
    
    int cvp = binarama(dizi, 0, 9,bul);
    if (cvp == -1){
        cout<<"Aranan eleman dizide yoktur";
        cout <<endl;
    } 
	else{
        cout<<"Aranan eleman dizide vardir ve indeksi: "<<cvp;
        cout <<endl;
    }
}
